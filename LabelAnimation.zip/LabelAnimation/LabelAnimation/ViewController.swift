//
//  ViewController.swift
//  LabelAnimation
//
//  Created by Lalit Arya on 12/04/19.
//  Copyright © 2019 Lalit Arya. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var lblNmae: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        setupViewLabels()
    }

    func setupViewLabels(){
        
       
        
let l4AttrString = background(string: "SANJAY SINGH")
        l4AttrString.append(strokeWidth(string: " Delhi"))
        l4AttrString.append(customizeColor(string: " ios Developer", color: UIColor.purple))
        lblNmae.attributedText = l4AttrString
    }
    
    
    func  customizeColor(string: String, color: UIColor) -> NSMutableAttributedString {
        return NSMutableAttributedString(string: string, attributes:
            [NSAttributedString.Key.foregroundColor : color ])
    }
    
    
    func strokeWidth(string: String) -> NSMutableAttributedString{
        return NSMutableAttributedString(string: string, attributes: [NSAttributedString.Key.strokeWidth: 2])
    }
    
    func background(string: String)-> NSMutableAttributedString {
        return NSMutableAttributedString(string: string, attributes:
            [NSAttributedString.Key.backgroundColor : UIColor.lightGray ])
    }
    
   
}

